﻿using $safeprojectname$.ViewModels;


namespace $safeprojectname$.Views
{
    public partial class MainWindow 
    {
        public MainWindow()
        {
            InitializeComponent();

            var vm = new MainViewModel();
            DataContext = vm;
            Closing += (sender, args) => vm.Dispose();
        }
    }
}
